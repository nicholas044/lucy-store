import {useState, useEffect} from 'react'
import axios from 'axios'

function SubCategoriesAPI() {
    const [subcategories, setsubCategories] = useState([])
    const [callback, setCallback] = useState(false)

    useEffect(() =>{
        const getsubCategories = async () =>{
            const res = await axios.get('/api/subcategory')
            setsubCategories(res.data)
        }

        getsubCategories()
    },[callback])
    return {
        subcategories: [subcategories, setsubCategories],
        callback: [callback, setCallback]
    }
}

export default SubCategoriesAPI
