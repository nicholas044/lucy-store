import React from 'react';
import {BrowserRouter} from 'react-router-dom'
import {DataProvider} from './GlobalState'
import Header from './components/headers/Header'
import MainPages from './components/mainpages/Pages'
import ThemeProvider from 'react-bootstrap/ThemeProvider'


function App() {
  
  return (
    <ThemeProvider
    breakpoints={['xxxl', 'xxl', 'xl', 'lg', 'md', 'sm', 'xs', 'xxs']}
    minBreakpoint="xxs">
    <DataProvider>
      <BrowserRouter>
       
          <MainPages />
      
      </BrowserRouter>
    </DataProvider>
    </ThemeProvider>
    
  );
}

export default App;
