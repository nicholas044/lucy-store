import React, { useContext, useState } from 'react'
import { GlobalState } from '../../GlobalState'
import { Link } from 'react-router-dom'
import axios from 'axios'
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import { FaHome } from 'react-icons/fa';
import { FaListUl } from 'react-icons/fa';
import { FaCartArrowDown } from 'react-icons/fa';
import { FaStore } from 'react-icons/fa';

function Footer() {
   

    return (
        <>
            <footer>
               <div class="footer d-block d-sm-none d-md-none">
                <ul>

                <li>
                 <span class="header"><FaHome />Home</span>
                </li>
                 <li>

                 <span class="header"><FaListUl />Category</span>

                 </li>
                 <li>

                 <span class="header"><FaCartArrowDown />Cart</span>

                 </li>
                 <li>
                 <span class="header"><FaStore />MyStore</span>

                 </li>
                </ul>
                </div>
                
                
               
            </footer>
           
        </>
    )
}

export default Footer
