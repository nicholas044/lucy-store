import React, {useState, useContext, useEffect} from 'react'
import axios from 'axios'
import {GlobalState} from '../../../GlobalState'
import Loading from '../utils/loading/Loading'
import {useNavigate, useParams} from 'react-router-dom'


const initialState = {
    name: '',
    description: '',
    category: '',
    _id: ''
}

function SubCategories() {
    const state = useContext(GlobalState)
    const [subcategory, setSubCategory] = useState(initialState)
    const [categories] = state.categoriesAPI.categories
    const [subcategories] = state.subcategoriesAPI.subcategories
    const [images, setImages] = useState(false)
    const [loading, setLoading] = useState(false)




    const [isAdmin] = state.userAPI.isAdmin
    const [token] = state.token

    const history = useNavigate()
    const param = useParams()

    const [onEdit, setOnEdit] = useState(false)
    const [callback, setCallback] = state.subcategoriesAPI.callback

    useEffect(() => {
        if(param.id){
            setOnEdit(true)
            subcategories.forEach(subcategory => {
                if(subcategory._id === param.id) {
                    setSubCategory(subcategory)
                    setImages(subcategory.image)
                }
            })
        }else{
            setOnEdit(false)
            setSubCategory(initialState)
            setImages(false)
        }
    }, [param.id, subcategories])

    const handleCheck = (id) =>{
      
        subcategories.forEach(subcategory => {
            if(subcategory._id === id) subcategory.checked = !subcategory.checked
        })
        setSubCategory([...subcategories])
    }

    const handleUpload = async e =>{
        e.preventDefault()
        try {
            if(!isAdmin) return alert("You're not an admin")
            const file = e.target.files[0]
            
            if(!file) return alert("File not exist.")

            if(file.size > 1024 * 1024) // 1mb
                return alert("Size too large!")

            if(file.type !== 'image/jpeg' && file.type !== 'image/png') // 1mb
                return alert("File format is incorrect.")

            let formData = new FormData()
            formData.append('file', file)

            setLoading(true)
            const res = await axios.post('/api/upload', formData, {
                headers: {'content-type': 'multipart/form-data', Authorization: token}
            })
            setLoading(false)
            setImages(res.data)

        } catch (err) {
            alert(err.response.data.msg)
        }
    }

    const handleDestroy = async () => {
        try {
            if(!isAdmin) return alert("You're not an admin")
            setLoading(true)
            await axios.post('/api/destroy', {public_id: images.public_id}, {
                headers: {Authorization: token}
            })
            setLoading(false)
            setImages(false)
        } catch (err) {
            alert(err.response.data.msg)
        }
    }

    const handleChangeInput = e =>{
        const {name, value} = e.target
        setSubCategory({...subcategory, [name]:value})
    }

    const handleSubmit = async e =>{
        e.preventDefault()
        try {
            if(!isAdmin) return alert("You're not an admin")
            if(!images) return alert("No Image Upload")

            if(onEdit){
                await axios.put(`/api/subcategory/${subcategory._id}`, {...subcategory, images}, {
                    headers: {Authorization: token}
                })
            }else{
                await axios.post('/api/subcategory', {...subcategory, images}, {
                    headers: {Authorization: token}
                })
            }
            setCallback(!callback)
            history.push("/")
        } catch (err) {
            alert(err.response.data.msg)
        }
    }

    const styleUpload = {
        display: images ? "block" : "none"
    }
    return (
        <div className="create_product">
            <form enctype="multipart/form-data">
            <div className="upload">
                <input type="file" multiple accept="image/*" name="file" id="file_up" onChange={handleUpload}/>
                {
                    loading ? <div id="file_img"><Loading /></div>

                    :<div id="file_img" style={styleUpload}>
                        <img src={images ? images.url : ''} alt=""/>
                        <span onClick={handleDestroy}>X</span>
                    </div>
                }
                
            </div>
            </form>
            <form onSubmit={handleSubmit}>
                
            <div className="row">
                    <label htmlFor="name">Name</label>
                    <textarea type="text" name="name" id="name" required
                    value={subcategory.name} rows="7" onChange={handleChangeInput} />
                </div>

                <div className="row">
                    <label htmlFor="description">Description</label>
                    <textarea type="text" name="description" id="description" required
                    value={subcategory.description} rows="5" onChange={handleChangeInput} />
                </div>

                

                <div className="row">
                    <label htmlFor="categories">Categories: </label>
                    <select name="category" value={subcategory.category} onChange={handleChangeInput} >
                        <option value="">Please select a category</option>
                        {
                            categories.map(category => (
                                <option value={category._id} key={category._id}>
                                    {category.name}
                                </option>
                            ))
                        }
                    </select>
                </div>
               

                <button type="submit">{onEdit? "Update" : "Create"}</button>
            </form>

        </div>
    )
}

export default SubCategories