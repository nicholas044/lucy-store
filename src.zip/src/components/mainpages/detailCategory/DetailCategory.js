import React, {useContext, useState, useEffect} from 'react'
import {useParams, Link} from 'react-router-dom'
import CategoryItem from '../utils/categoryItem/CategoryItem'


import {GlobalState} from '../../../GlobalState'


function DetailCategory() {
    const params = useParams()
    const state = useContext(GlobalState)
    const [products] = state.productsAPI.products

    const [categories] = state.categoriesAPI.categories
    const [detailCategory, setDetailCategory] = useState([])

    useEffect(() =>{
        if(params.id){

            categories.forEach(category => {
                if(category._id === params.id) setDetailCategory(category)
            })
        }
    },[params.id, categories])

    if(detailCategory.length === 0) return null;

    return (
        <>
    
         <p>{detailCategory.name}</p>
         
          <div className="products">
            
            {
                categories.map(category => {
                    return <CategoryItem key={category._id} category={category}
                    />
                })
            } 
        </div>
        
        <div className="products">
                    {
                        categories.map(category => {
                            return category.subcategory === detailCategory.subcategory
                                ? <CategoryItem key={category._id} category={category}/> : null
                        })
                    }
    </div> 
    
               
        </>
    )
}

export default DetailCategory
