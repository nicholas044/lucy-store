import React from 'react';
import Carousel from 'react-bootstrap/Carousel';
import Sidemenu from '../sidemenu/Sidemenu'
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';



function Home() {
  return (
    <>
    <Container fluid>
      <div className="frontstart">

      <Row className="d-none d-md-flex d-lg-flex">
      <Col sm={3} className="p-0 m-0" style={{background:"white"}}>
          <Sidemenu />

        </Col>
        {/*start slider*/}
        <Col md={7}>
        <div>
        <Carousel variant="dark">
        
      <Carousel.Item >
        <img
          className="d-block w-100"
          src="/images/image1.jpg"
          style = {{
            'height':350,
          }}
          alt="First slide"
        />
        <Carousel.Caption>
          <h5>First slide label</h5>
          <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src="/images/image2.jpg"
          style = {{
            'height':350,
          }}
          alt="Second slide"
        />
        <Carousel.Caption>
          <h5>Second slide label</h5>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src="/images/image3.jpg"
          style = {{
            'height':350,
          }}
          alt="Third slide"
        />
        <Carousel.Caption>
        <h5>Second slide label</h5>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>    
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src="/images/image4.jpg"
          style = {{
            'height':350,
          }}
          alt="Fourth slide"
        />
        <Carousel.Caption>
        <h5>Second slide label</h5>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
    </div>
    <Container fluid className="con-slider">
      <Row>
        <Col sm={6} className="p-0 m-0">
        <div className="belowslider1 ">
            <p>Men s shoes</p>
            <button className="button-slider">View &gt;</button>
        </div>

        <div className="belowslider1">
            <p>Men s shoes</p>
            <button className="button-slider">View &gt;</button>
        </div>
        </Col>
        <Col sm={6} className="p-0 m-0">
        <div className="belowslider2">
            <p>Men s shoes</p>
            <button className="button-slider">View &gt;</button>
        </div>

        <div className="belowslider2">
            <p>Men s shoes</p>
            <button className="button-slider">View &gt;</button>
        </div>
        </Col>
      </Row>
    </Container>
        </Col>
        {/*End slide*/}

        <Col sm={2} className="p-0 m-0" style={{background:"white"}}>
         <div className="right-to-slider">

         </div>
        </Col>
      </Row>
      </div>
      
    </Container>


    </>
  );
}

export default Home;