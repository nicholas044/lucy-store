import React, {useContext, useEffect, useState} from 'react'
import {GlobalState} from '../../../GlobalState'
import ProductItem from '../utils/productItem/ProductItem'
import Loading from '../utils/loading/Loading'
import axios from 'axios'
import Filters from './Filters'
import LoadMore from './LoadMore'
import Home from './Home'
import Slider from './Slider'
import Containeresm from 'react-bootstrap/esm/Container'
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import CountdownTimer from '../timer/CountdownTimer';
import { useNavigate, useParams, useSearchParams, useLocation } from 'react-router-dom'


function Products() {
    const THREE_DAYS_IN_MS = 3 * 24 * 60 * 60 * 1000;
    const NOW_IN_MS = new Date().getTime();
    const dateTimeAfterThreeDays = NOW_IN_MS + THREE_DAYS_IN_MS;
    const state = useContext(GlobalState)
    const [products, setProducts] = state.productsAPI.products
    console.log({products});
    
    const [isAdmin] = state.userAPI.isAdmin
    const [token] = state.token
    const [callback, setCallback] = state.productsAPI.callback
    const [loading, setLoading] = useState(false)
    const [isCheck, setIsCheck] = useState(false)
    const [searchParams, setSearchParams] = useSearchParams(); 
    const [query, setQuery] = useState(searchParams.get('query')); 

    const { params } = useParams();
    
    const handleCheck = (id) =>{
      
        products.forEach(product => {
            if(product._id === id) product.checked = !product.checked
        })
        setProducts([...products])
    }

    const deleteProduct = async(id, public_id) => {
        try {
            setLoading(true)
            const destroyImg = axios.post('/api/destroy', {public_id},{
                headers: {Authorization: token}
            })
            const deleteProduct = axios.delete(`/api/products/${id}`, {
                headers: {Authorization: token}
            })

            await destroyImg
            await deleteProduct
            setCallback(!callback)
            setLoading(false)
        } catch (err) {
            alert(err.response.data.msg)
        }
    }

    const checkAll = () =>{
        products.forEach(product => {
            product.checked = !isCheck
        })
        setProducts([...products])
        setIsCheck(!isCheck)
    }

    const deleteAll = () =>{
        products.forEach(product => {
            if(product.checked) deleteProduct(product._id, product.images.public_id)
        })
    }


    


   //  if(loading) return <div><Loading /></div>

   /* useEffect(() => {
      const query = queryString.parse(window.location.search);
      const modifiedQuery = {
        ...query,
        target: query
      }
      history.replace({
        pathname: window.location.pathname,
        search: query.stringify(modifiedQuery)
      })
        
    }) */
    return (
        <>
        <div>
          <Home />
        </div>
        <Container fluid>
        <Row>
            <Col>
            <div className="left-slider">
                <CountdownTimer targetDate={dateTimeAfterThreeDays}/>
            </div>
            </Col>
            <Col sm={8}>
                <div className="slider-size">
                  <Slider />   
                </div>
            </Col>
        </Row>
        </Container>
       
        
        {
            isAdmin && 
            <div className="delete-all">
                <span>Select all</span>
                <input type="checkbox" checked={isCheck} onChange={checkAll} />
                <button onClick={deleteAll}>Delete ALL</button>
            </div>
        }
         <div class="head-rounded">
         <hr class="rounded"/>
                <h1 style={{fontSize:"24px", fontWeight:"700", paddingLeft:"15px", marginTop:"10px"}}>Today s Deals</h1>
            </div>
            <Filters />
        <div className="products">
            
            {
                products.map(product => {
                    return <ProductItem key={product._id} product={product}
                    isAdmin={isAdmin} deleteProduct={deleteProduct} handleCheck={handleCheck} />
                })
            } 
        </div>

        <LoadMore />
        {products.length === 0 && <Loading />}
        </>
    )
}

export default Products