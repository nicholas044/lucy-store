import React, {useContext, useHistory} from 'react'
import {GlobalState} from '../../../GlobalState'
import Container from 'react-bootstrap/Container'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import { Link } from 'react-router-dom'



function Filters() {
    const state = useContext(GlobalState)
    const [subcategories] = state.subcategoriesAPI.subcategories


    const [category, setCategory] = state.productsAPI.category
    const [sort, setSort] = state.productsAPI.sort
    const [search, setSearch] = state.productsAPI.search

    const handleCategory = e => {
      
      const {name, value } = e.target;
        setCategory(e.target.value)
        setSearch('')
    }
    const onSubmit = (e) => {
        e.preventDefault();
    };
    return (
        <Container fluid className="mt-4">
        <Row>
          <Col>
            <div className="row sm-3">
                <span>Filters: </span>
                <select name="category" value={category} onChange={handleCategory} >
                    <option value=''>All Products</option>
                    {
                        subcategories.map(subcategory => (
                            <option value={"subcategory=" + subcategory._id} key={subcategory._id}>
                                {subcategory.name}
                            </option>
                        ))
                    }
                </select>
            </div>
          </Col>
          <Col>
          <div>
            <form
            action="/"
            method="get"
            autoComplete="off"
            onSubmit={onSubmit}
        >
          <label className="sm-6 mt-3">
          <input type="text"  value={search}  placeholder="Enter your search!"
            onInput={(e) => setSearch(e.target.value)} />
          </label> 
          <button type="submit">Search</button>
        </form>s
          </div>
          
          </Col>
          <Col>
          <div className="row sort sm-3">
                <span>Sort By: </span>
                <select value={sort} onChange={e => setSort(e.target.value)} >
                    <option value=''>Newest</option>
                    <option value='sort=oldest'>Oldest</option>
                    <option value='sort=-sold'>Best sales</option>
                    <option value='sort=-price'>Price: Hight-Low</option>
                    <option value='sort=price'>Price: Low-Hight</option>
                </select>
            </div>

          </Col>
        </Row>
      </Container>
    )
}

export default Filters