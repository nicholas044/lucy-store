import React from 'react';
import { Link, Outlet } from "react-router-dom"
import {BrowserRouter} from 'react-router-dom'
import ThemeProvider from 'react-bootstrap/ThemeProvider'

function onlyHeader( ) {
   
    
  return (
    <>
   

    <ThemeProvider
    breakpoints={['xxxl', 'xxl', 'xl', 'lg', 'md', 'sm', 'xs', 'xxs']}
    minBreakpoint="xxs">
      <BrowserRouter>
        <div className="App">
        <div>
    <h1>Welcome to the app!</h1>
    <nav>
    <Link to="/cart">Invoices</Link> |{" "}
    <Link to="/cart">Dashboard</Link>
    </nav>
    </div>


    <Outlet />
        </div>
      </BrowserRouter>
    </ThemeProvider>
    </>
  );
}

export default onlyHeader;