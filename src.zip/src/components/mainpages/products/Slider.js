import React, {useContext, useState} from 'react'
import {GlobalState} from '../../../GlobalState'
import ProductItem from '../utils/productItem/ProductItem'

function Slider() {
  const state = useContext(GlobalState)
  const [products, setProducts] = state.productsAPI.products
  
  const handleCheck = (id) =>{
    products.forEach(product => {
        if(product._id === id) product.checked = !product.checked
    })
    setProducts([...products])
}
  return (
    <>
    <div class="scrolling-wrapper">
			
            {
                products.map(product => {
                    return <div className="slider"><ProductItem key={product._id} product={product} /></div>
                })
            } 
			
		</div>	

    </>
  );
}

export default Slider;