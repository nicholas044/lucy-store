import React, {useEffect, useState} from 'react'

import {Link} from 'react-router-dom'
import Card from 'react-bootstrap/Card';
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';

function ProductItem({product, isAdmin, deleteProduct, handleCheck}) {
  const [image, setImage] = useState([])

  useEffect(() => {
    window.scrollTo(0, 0)
  })
    return (

        <Row>
        <Link to={`/detail/${product._id}`}>
        {Array.from({ length: 1 }).map((_, idx) => (

          <Col>
            <Card className="m-2">
            <img src={ product.multiple_image[2].url } alt="" />
             
              <Card.Body>
                <Card.Title><center> {product.title}</center></Card.Title>
                <Card.Text>
                  <p style={{background:"black"}}>{product.discount}</p>
                    <center>
                     {product.description}
                    </center>
                </Card.Text>
              </Card.Body>
            </Card>
          </Col>
          ))}
      </Link>
         
      </Row>

    )
}

export default ProductItem