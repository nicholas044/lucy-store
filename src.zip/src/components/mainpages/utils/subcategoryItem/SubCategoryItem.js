import React, {useEffect} from 'react'

import {Link} from 'react-router-dom'
import Card from 'react-bootstrap/Card';
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';

function SubCategoryItem({subcategory,setCategory, isAdmin, deleteProduct, handleCheck}) {
  useEffect(() => {
    window.scrollTo(0, 0)
  })
    return (
        <Row>
            <Link onClick={() => setCategory('newCategory')}>
        
        {Array.from({ length: 1 }).map((_, idx) => (

          <Col>
            <Card className="m-2">
              <Card.Body>
                <Card.Title><center>{subcategory.name}</center></Card.Title>
                <Card.Text>
                  <p>{subcategory.category}</p>
                </Card.Text>
              </Card.Body>
            </Card>
          </Col>
          ))}
      </Link>
         
      </Row>

    )
}

export default SubCategoryItem