import React from 'react'
import {Link} from 'react-router-dom'



function Sidemenu() {
 
  return (
    <>
      <div class="col">
                    <div class="hero__categories">
                        <div class="hero__categories__all">
                            <span>Shop by Category</span>
                        </div>
                        <ul>
                           {/*start menu*/}
                     
            <li class="menubutton">
            <a className = "nav-link px-2">
                <div id="link-1" class="nav-item dropdown-hover mx-2">
        <a class="nav-link dropdown-hover-button" href="#">Clothing</a>
        <div class="spacer dropdown-hover-content">
          <div class="row">
            <div class="col-lg-3">
              <div class="mb-3 pl-2">
                <h6><a class="colour-2" href="#">Men s Clothes</a></h6>
                <div>
               <Link to={`/subdetails/632ec921f306da0ab0027ee9`}>
                Shirt
                </Link>
                <a class="dropdown-item p-0" href="#">Trouser</a>
                <a class="dropdown-item p-0" href="#">Pants</a>
                <a class="dropdown-item p-0" href="#">Socks</a>
                <a class="dropdown-item p-0" href="#">Jeans</a>
                <a class="dropdown-item p-0" href="#">Swim wear</a>
                <a class="dropdown-item p-0" href="#">Sweater</a>
                <a class="dropdown-item p-0" href="#">Underwear</a>
                <a class="dropdown-item p-0" href="#">Shorts</a>
                </div>
                
              </div>
            </div>
            <div class="col-lg-3">
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Sports Wear</a></h6>
                <a class="dropdown-item p-0" href="#">Jersey</a>
                <a class="dropdown-item p-0" href="#">Boots</a>
              </div>
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Special use</a></h6>
                <a class="dropdown-item p-0" href="#">Socks</a>
                <a class="dropdown-item p-0" href="#">Belts</a>
                <a class="dropdown-item p-0" href="#">Watch</a>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Women s Clothes</a></h6>
                <a class="dropdown-item p-0" href="#">Dresses</a>
                <a class="dropdown-item p-0" href="#">Tops</a>
                <a class="dropdown-item p-0" href="#">Underwear</a>
                <a class="dropdown-item p-0" href="#">Jeans</a>
                <a class="dropdown-item p-0" href="#">Sweater</a>
                <a class="dropdown-item p-0" href="#">Skirts</a>
              </div>
              <div class="mb-3">
                <h6><a class="colour-2" href="#">World Apparel</a></h6>
                <a class="dropdown-item p-0" href="#">Africa clothes</a>
                <a class="dropdown-item p-0" href="#">Moslim clothes</a>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Accessories</a></h6>
                <a class="dropdown-item p-0" href="#">Sun glasses</a>
                <a class="dropdown-item p-0" href="#">Hats</a>
                <a class="dropdown-item p-0" href="#">Caps</a>
                <a class="dropdown-item p-0" href="#">Belts</a>
                <a class="dropdown-item p-0" href="#">Gloves</a>
                <a class="dropdown-item p-0" href="#">Wraps</a>
                <a class="dropdown-item p-0" href="#">Head wear</a>
              </div>
              
            </div>
          </div>
        </div>
      </div>
              </a>
            </li>
           
                           {/*end menu*/}

                                       {/*start menu*/}
                     
            <li class="menubutton">
            <a className = "nav-link px-2">
                <div id="link-1" class="nav-item dropdown-hover mx-2">
        <a class="nav-link dropdown-hover-button" href="#">Shoes</a>
        <div class="spacer dropdown-hover-content">
          <div class="row">
            <div class="col-lg-3">
              <div class="mb-3 pl-2" style={{width:"900px", align:"top"}}>
                <h6><a class="colour-2" href="#">Heading 1</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Heading 2</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Heading 3</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Heading 4</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Heading 5</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Heading 6</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Heading 7</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
            </div>
          </div>
        </div>
      </div>
              </a>
            </li>
           
                           {/*end menu*/}

                                       {/*start menu*/}
                     
            <li class="menubutton">
            <a className = "nav-link px-2">
                <div id="link-1" class="nav-item dropdown-hover mx-2">
        <a class="nav-link dropdown-hover-button" href="#">Luggage & Bags</a>
        <div class="spacer dropdown-hover-content">
          <div class="row">
            <div class="col-lg-3">
              <div class="mb-3 pl-2" style={{width:"900px", align:"top"}}>
                <h6><a class="colour-2" href="#">Heading 1</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Heading 2</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Heading 3</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Heading 4</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Heading 5</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Heading 6</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Heading 7</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
            </div>
          </div>
        </div>
      </div>
              </a>
            </li>
           
                           {/*end menu*/}

                                       {/*start menu*/}
                     
            <li class="menubutton">
            <a className = "nav-link px-2">
                <div id="link-1" class="nav-item dropdown-hover mx-2">
        <a class="nav-link dropdown-hover-button" href="#">Watch & Jewelry</a>
        <div class="spacer dropdown-hover-content">
          <div class="row">
            <div class="col-lg-3">
              <div class="mb-3 pl-2" style={{width:"900px", align:"top"}}>
                <h6><a class="colour-2" href="#">Heading 1</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Heading 2</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Heading 3</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Heading 4</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Heading 5</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Heading 6</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Heading 7</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
            </div>
          </div>
        </div>
      </div>
              </a>
            </li>
           
                           {/*end menu*/}

                                       {/*start menu*/}
                     
            <li class="menubutton">
            <a className = "nav-link px-2">
                <div id="link-1" class="nav-item dropdown-hover mx-2">
        <a class="nav-link dropdown-hover-button" href="#">Kids & Toys</a>
        <div class="spacer dropdown-hover-content">
          <div class="row">
            <div class="col-lg-3">
              <div class="mb-3 pl-2" style={{width:"900px", align:"top"}}>
                <h6><a class="colour-2" href="#">Heading 1</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Heading 2</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Heading 3</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Heading 4</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Heading 5</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Heading 6</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Heading 7</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
            </div>
          </div>
        </div>
      </div>
              </a>
            </li>
           
                           {/*end menu*/}

                                       {/*start menu*/}
                     
            <li class="menubutton">
            <a className = "nav-link px-2">
                <div id="link-1" class="nav-item dropdown-hover mx-2">
        <a class="nav-link dropdown-hover-button" href="#">Home & Appliances</a>
        <div class="spacer dropdown-hover-content">
          <div class="row">
            <div class="col-lg-3">
              <div class="mb-3 pl-2" style={{width:"900px", align:"top"}}>
                <h6><a class="colour-2" href="#">Heading 1</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Heading 2</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Heading 3</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Heading 4</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Heading 5</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Heading 6</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
              <div class="mb-3">
                <h6><a class="colour-2" href="#">Heading 7</a></h6>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
                <a class="dropdown-item p-0" href="#">Sub Page</a>
              </div>
            </div>
          </div>
        </div>
      </div>
              </a>
            </li>
           
                           {/*end menu*/}

                           
                        </ul>
                    </div>
                </div>
   </>
  );
}
export default Sidemenu;