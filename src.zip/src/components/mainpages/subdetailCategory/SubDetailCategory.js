import React, {useContext, useEffect, useState} from 'react'
import {GlobalState} from '../../../GlobalState'
import ProductItem from '../utils/productItem/ProductItem'
import {useParams, Link} from 'react-router-dom'


function Child() {
    const state = useContext(GlobalState)
    const [products] = state.productsAPI.products
    const [subcategories] = state.subcategoriesAPI.subcategories
    const [token] = state.token
    const [callback, setCallback] = state.productsAPI.callback
    const [loading, setLoading] = useState(false)
    const [detailSubCategory, setDetailSubCategory] = useState([])
    const params = useParams()
    
    useEffect(() =>{
      if(params.id){

        subcategories.forEach(subcategory => {
              if(subcategory._id === params.id) setDetailSubCategory(subcategory)
          })
      }
    },[params.id, subcategories])

    if(detailSubCategory.length === 0) return null;
    
  
    return (
      <div>
         {products
        .filter(product => {
          return product.subcategory === detailSubCategory._id;
        })
        .map(product => {
          return (
            <div className="products">
            <ProductItem key={product._id} product={product} />
            </div>
          );
        })}
      </div>
    );
  }
export default Child
  