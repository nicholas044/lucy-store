import React from 'react'

function Menu({menuItems}) {
    return (
        <div>
            {
                menuItems.map((item) => {
                    return <div key={item.id}>
                        <div>
                            <img src = {item.image} alt=""/>
                            <h2>{item.title}</h2>
                            <p>{item.description}</p>

                        </div>
                    </div>
                })
            }
        </div>
    )
}

export default Menu;