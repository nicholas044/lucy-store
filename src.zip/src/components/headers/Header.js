import React, { useContext, useState } from 'react'
import { GlobalState } from '../../GlobalState'
import Menu from './icon/menu.svg'
import Close from './icon/close.svg'
import Cart from './icon/cart.svg'
import { Link } from 'react-router-dom'
import axios from 'axios'
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

function Header() {
    const state = useContext(GlobalState)
    const [isLogged] = state.userAPI.isLogged
    const [isAdmin] = state.userAPI.isAdmin
    const [search, setSearch] = state.productsAPI.search
    const [cart] = state.userAPI.cart
    const [menu, setMenu] = useState(false)

    const logoutUser = async () => {
        await axios.get('/user/logout')

        localStorage.removeItem('firstLogin')

        window.location.href = "/";
    }

    const adminRouter = () => {
        return (
            <>
                <span><Link className="menu-below-headers" to="/">Products</Link></span>
                <span><Link className="menu-below-headers" to="/create_product">Create Product</Link></span>
                <span><Link className="menu-below-headers" to="/category">Categories</Link></span>
            </>
        )
    }

    const loggedRouter = () => {
        return (
            <>
                <span><Link to="/history" className="header__cart__logout">History</Link></span>
                <span><Link class="header__cart__logout" to="/" onClick={logoutUser}>Logout</Link></span>
            </>
        )
    }


    const styleMenu = {
        left: menu ? 0 : "-100%"
    }

    return (
        <>
            <header>
                <div class="header__top">
                    <Container fluid>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="header__top__left">
                                    <ul>
                                        <li><i class="fa fa-envelope"></i>Nick Home</li>
                                        <li>
                                          <div class="header__cart__price"><span>Login | Register</span></div>

                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="header__top__right">
                                    <div class="header__top__right__social">
                                        <a href="#"><i class="fa fa-facebook"></i></a>
                                        <a href="#"><i class="fa fa-twitter"></i></a>
                                        <a href="#"><i class="fa fa-linkedin"></i></a>
                                        <a href="#"><i class="fa fa-pinterest-p"></i></a>
                                    </div>
                                    <div class="header__top__right__language">
                                        <img src="img/language.png" alt="" />
                                        <div>English</div>
                                        <span class="arrow_carrot-down"></span>
                                        <ul className="p-2">
                                            <li><a href="#">Spanish</a></li>
                                            <li><a href="#">English</a></li>
                                        </ul>
                                    </div>
                                    <div class="header__top__right__auth">
                                        <a href="#"><i class="fa fa-user"></i> Chat with us</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </Container>
                </div>
                <Container fluid className="headers">
                <div className="padding-header">
                <Row>
                <Col sm={3}>
                <div className="header__logo">
                <h1>
                    <Link to="/" className="link1">{isAdmin ? 'Admin' : 'Nick Shop'}</Link>
                </h1>
                </div>
                </Col>


                <Col sm={6}>
                <nav class="header__menu">
                                <Form className="d-flex">
                                    <Form.Control
                                        type="search"
                                        placeholder="What are you looking for?"
                                        className="me-2"
                                        aria-label="Search"
                                        onChange={e => setSearch(e.target.value.toLowerCase())}
                                    />
                                    <Button variant="outline-success">Search</Button>
                                </Form>
                </nav>
                </Col>

                <Col sm={3}>
                <div class="header__cart">
                            <div className="cart-icon">
                            <span>{cart.length}</span>
                            <Link to="/cart">
                             <img src={Cart}  alt="" width="30" />
                            </Link>
                            </div>
                                <div>
                                    <span>
                                      
                                     {
                                        isLogged ? loggedRouter() : <span><Link className="header__cart__logout" to="/login">Login ✥ Register</Link></span>
                                     }
                                    </span>
                                </div>
                </div>
                </Col>
                
                </Row>
                </div>
                
                   
                 
                </Container>
            </header>
            <Container fluid>
            <Row>
                    <Col sm={8}>
                       <div className="menu-below-header">

                                 {isAdmin && adminRouter()}

                       </div>
                    </Col>
                </Row>
            </Container>
        </>
    )
}

export default Header
